const express = require("express");
const router = express.Router();
const { Pool } = require("pg");
const jwtAuth = require("../middleware/jwtAuth");
require("dotenv").config();

const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
});

router.use(jwtAuth);

router.get("/", async (req, res) => {
  const user_id = req.user.id;

  try {
    const deviceRes = await pool.query(
      `SELECT device_id FROM devices WHERE user_id = $1`,
      [user_id]
    );

    if (!deviceRes.rows.length) {
      return res.status(404).json({ msg: "No device found for this user" });
    }

    const device_id = deviceRes.rows[0].device_id;

    const { rows } = await pool.query(
      `SELECT * FROM particle_data
       WHERE device_id = $1
       ORDER BY measured_at DESC
       LIMIT 100`,
      [device_id]
    );

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Server error" });
  }
});

module.exports = router;
