const express = require("express");
const router = express.Router();
const { Pool } = require("pg");
const { generateToken } = require("../utils/jwt");
require("dotenv").config();

const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
});

router.post("/register", async (req, res) => {
  const { username, password, device_id } = req.body;

  try {
    const userResult = await pool.query(
      `INSERT INTO users (username, password_hash)
       VALUES ($1, crypt($2, gen_salt('bf')))
       RETURNING id, username`,
      [username, password]
    );

    const user = userResult.rows[0];

    await pool.query(
      `INSERT INTO devices (device_id, user_id)
       VALUES ($1, $2)`,
      [device_id, user.id]
    );

    const token = generateToken(user);
    res.json({ token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Registration failed" });
  }
});

router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    const result = await pool.query(
      `SELECT id, username FROM users
       WHERE username = $1 AND password_hash = crypt($2, password_hash)`,
      [username, password]
    );

    if (!result.rows.length) {
      return res.status(401).json({ msg: "Invalid username or password" });
    }

    const user = result.rows[0];
    const token = generateToken(user);
    res.json({ token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Login failed" });
  }
});

module.exports = router;
