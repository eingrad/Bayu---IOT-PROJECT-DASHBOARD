const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5050;

app.use(cors());
app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.send("Dasuto Public API is online");
});

app.use("/auth", require("./routes/auth"));
app.use("/api/sensor-data", require("./routes/sensorData"));

app.listen(PORT, () => {
  console.log(`Public API running at http://localhost:${PORT}`);
});
