require("dotenv").config();

const express = require("express");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const { Pool } = require("pg");

const { format } = require("@fast-csv/format");

const bodyParser = require("body-parser");
const mqtt = require("mqtt");
const WebSocket = require("ws");
const http = require("http");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.json());

// Create HTTP server and attach to Express
const server = http.createServer(app);

// Database connection pools
const poolAdmin = new Pool({
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT, 10),
  database: process.env.DB_NAME,
  user: process.env.DB_ADMIN_USER,
  password: process.env.DB_ADMIN_PASS,
});

const poolUser = new Pool({
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT, 10),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_USER_PASS,
});

// JWT authentication middleware

/*function authenticateJWT(req, res, next) {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.split(" ")[1];
  if (!token) return res.status(401).json({ msg: "Token Needed" });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ msg: "Unverified Token" });
  }
}*/

function authenticateJWT(req, res, next) {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.split(" ")[1];
  if (!token) return res.status(401).json({ msg: "Token Needed" });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    console.log("✅ Verified token payload:", req.user);
    next();
  } catch (err) {
    console.error("❌ JWT error:", err.message);
    res.status(401).json({ msg: "Unverified Token" });
  }
}

// Admin authorization middleware
function authorizeAdmin(req, res, next) {
  if (req.user.role !== "admin") {
    return res.status(403).json({ msg: "Admin Only" });
  }
  next();
}

// -----------------------------------------------------------------
// 1) GET /companies  — list all companies (admin only)
// -----------------------------------------------------------------
app.get("/companies", authenticateJWT, authorizeAdmin, async (req, res) => {
  try {
    const { rows } = await poolAdmin.query(
      `SELECT id, name
           FROM companies
       ORDER BY name`
    );
    res.json(rows);
  } catch (err) {
    console.error("GET /companies error:", err);
    res.status(500).json({ msg: "Server Error" });
  }
});

// -----------------------------------------------------------------
// 2) POST /users  — create a new user (admin only)
// -----------------------------------------------------------------
app.post("/users", authenticateJWT, authorizeAdmin, async (req, res) => {
  const { username, password, role, company_id } = req.body;
  if (!company_id) {
    return res.status(400).json({ msg: "company_id is required" });
  }

  const { rows: comps } = await poolAdmin.query(
    `SELECT email_domain
         FROM companies
        WHERE id = $1`,
    [company_id]
  );
  if (comps.length === 0) {
    return res.status(400).json({ msg: "Invalid company_id" });
  }
  const { email_domain } = comps[0];

  if (!username.endsWith("@" + email_domain)) {
    return res.status(400).json({
      msg: `Username must end with @${email_domain}`,
    });
  }

  try {
    const { rows } = await poolAdmin.query(
      `INSERT INTO users
             (username, password_hash, role, company_id)
           VALUES
             ($1, crypt($2, gen_salt('bf')), $3, $4)
           RETURNING id, username, role, created_at, company_id`,
      [username, password, role, company_id]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error("POST /users error:", err.message);
    res.status(500).json({ msg: "Server Error" });
  }
});

// -----------------------------------------------------------------
// 3) GET /users  — list all users (admin only)
// -----------------------------------------------------------------
app.get("/users", authenticateJWT, authorizeAdmin, async (req, res) => {
  try {
    const { rows } = await poolAdmin.query(
      `SELECT id, username, role, created_at, company_id
           FROM users
        ORDER BY created_at DESC`
    );
    res.json(rows);
  } catch (err) {
    console.error("GET /users error:", err);
    res.status(500).json({ msg: "Server Error" });
  }
});

// -----------------------------------------------------------------
// 4) POST /login — user login
// -----------------------------------------------------------------
app.post("/login", async (req, res) => {
  const { username, password } = req.body;
  try {
    const { rows } = await poolAdmin.query(
      `SELECT id, role
         FROM users
        WHERE username = $1
          AND password_hash = crypt($2, password_hash)`,
      [username, password]
    );
    if (!rows.length) {
      return res.status(401).json({ msg: "Wrong Email or Password!" });
    }
    const { id, role } = rows[0];
    const token = jwt.sign({ id, role }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    res.json({ token });
  } catch (err) {
    console.error("POST /login error:", err);
    res.status(500).json({ msg: "Server Error" });
  }
});

// -----------------------------------------------------------------
// 5) GET /wind-data — latest wind readings (any authenticated user)
// -----------------------------------------------------------------
app.get("/wind-data", authenticateJWT, async (req, res) => {
  try {
    const { rows } = await poolUser.query(
      `SELECT * FROM wind_data ORDER BY measured_at DESC LIMIT 100`
    );
    res.json(rows);
  } catch (err) {
    console.error("GET /wind-data error:", err);
    res.status(500).json({ msg: "Server Error" });
  }
});

// -----------------------------------------------------------------
// 6) GET /particle-data — latest particle readings (any authenticated user)
// -----------------------------------------------------------------
app.get("/particle-data", authenticateJWT, async (req, res) => {
  try {
    const { rows } = await poolUser.query(
      `SELECT * FROM particle_data ORDER BY measured_at DESC LIMIT 100`
    );
    res.json(rows);
  } catch (err) {
    console.error("GET /particle-data error:", err);
    res.status(500).json({ msg: "Server Error" });
  }
});

//-- ------------------------------
// Licenses
// ------------------------------

app.get("/license", authenticateJWT, async (req, res) => {
  try {
    const userId = req.user.id;
    const result = await poolUser.query(
      `SELECT license_key, company, issued_at, expires_at, 
              CASE 
                WHEN expires_at < NOW() THEN 'expired'
                ELSE 'active'
              END AS status
       FROM licenses
       WHERE user_id = $1
       ORDER BY issued_at DESC
       LIMIT 1`,
      [userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "No license found for user." });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("GET /license error:", err.message);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ------------------------------
// Sensor Info Cards
// ------------------------------

app.get("/device/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const result = await poolUser.query("SELECT * FROM devices WHERE id = $1", [
      id,
    ]);
    if (result.rows.length === 0)
      return res.status(404).json({ error: "Device not found" });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ------------------------------
// Device Info Cards & Latest Data With Particle and Wind Data
// ------------------------------

app.get("/device-info/:id", async (req, res) => {
  const { id } = req.params;

  try {
    // 1. Device Info
    const deviceResult = await poolUser.query(
      `SELECT id, location, battery, status FROM devices WHERE id = $1`,
      [id]
    );
    if (deviceResult.rows.length === 0) {
      return res.status(404).json({ error: "Device not found" });
    }
    const device = deviceResult.rows[0];

    // 2. Latest Particle Data
    const particleResult = await poolUser.query(
      `SELECT pm25, pm10, tsp, measured_at FROM particle_data 
       WHERE device_id = $1 
       ORDER BY measured_at DESC 
       LIMIT 1`,
      [id]
    );
    const particle = particleResult.rows[0] || {};

    // 3. Latest Wind Data
    const windResult = await poolUser.query(
      `SELECT humidity, pressure, humidity, temperature, measured_at FROM wind_data 
       WHERE device_id = $1 
       ORDER BY measured_at DESC 
       LIMIT 1`,
      [id]
    );
    const wind = windResult.rows[0] || {};

    // 4. Combine all into one response
    res.json({
      ...device,
      ...particle,
      ...wind,
      last_updated: particle.measured_at || wind.measured_at || null,
    });
  } catch (err) {
    console.error("❌ GET /device-info/:id failed:", err.message);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ------------------------------
// My Devices Endpoint
// ------------------------------

app.get("/my-devices", authenticateJWT, async (req, res) => {
  const userId = req.user.id;
  try {
    const result = await poolUser.query(
      `SELECT id, device_name, location, latitude, longitude FROM devices WHERE user_id = $1`,
      [userId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error("GET /my-devices error:", err.message);
    res.status(500).json({ msg: "Server error" });
  }
});

// ------------------------------
// MQTT to WebSocket Bridge
// ------------------------------
const MQTT_BROKER = "mqtt://192.168.0.205:1883"; //"mqtt://eetsb-server.duckdns.org:1883";  //"mqtt://192.168.0.205:1883"; //"mqtt://192.168.25.99:1883";  //-change MQTT broker URL
const MQTT_TOPICS = [
  "v1/devices/me/telemetry", // wind, temp, humidity, pressure
  "v1/devices/me/telemetry2", // pm25, pm10, tsp
];

const mqttClient = mqtt.connect(MQTT_BROKER);

// WebSocket server
const wss = new WebSocket.Server({ server });
const clients = new Set();

wss.on("connection", (ws) => {
  console.log("🔌 WebSocket client connected");
  clients.add(ws);
  ws.on("close", () => clients.delete(ws));
});

// MQTT connection and topic subscription
mqttClient.on("connect", () => {
  console.log("✅ Connected to MQTT broker");

  mqttClient.subscribe(MQTT_TOPICS, (err) => {
    if (err) {
      console.error("❌ MQTT subscribe error:", err);
    } else {
      console.log(`📡 Subscribed to topics: ${MQTT_TOPICS.join(", ")}`);
    }
  });
  MQTT_TOPICS.forEach((topic) => {
    mqttClient.subscribe(topic, (err) => {
      if (err) {
        console.error(`❌ MQTT subscribe error for ${topic}:`, err);
      } else {
        console.log(`📡 Subscribed to topic: ${topic}`);
      }
    });
  });
});

// Relay MQTT message to all WebSocket clients
mqttClient.on("message", (topic, message) => {
  const payload = message.toString();

  const wsMessage = JSON.stringify({
    topic,
    data: payload,
  });

  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(wsMessage);
    }
  }
});

// Start the combined server
server.listen(PORT, () => {
  console.log(`🚀 Server (HTTP + WS) listening on http://localhost:${PORT}`);
});

// ------------------------------
// CSV Download Endpoints
// ------------------------------

//Particle Data
app.get("/download/particle-data", authenticateJWT, async (req, res) => {
  const { fields, start, end } = req.query;

  const allowedFields = ["pm25", "pm10", "tsp"];
  const selected = fields
    ? fields.split(",").filter((f) => allowedFields.includes(f))
    : allowedFields;

  if (selected.length === 0) {
    return res.status(400).json({ msg: "No valid fields selected" });
  }

  const conditions = [];
  const params = [];

  if (start) {
    const paramIndex = params.length + 1;
    conditions.push(`measured_at >= $${paramIndex}`);
    params.push(start);
  }

  if (end) {
    const paramIndex = params.length + 1;
    conditions.push(`measured_at <= $${paramIndex}`);
    params.push(end);
  }

  const whereClause = conditions.length
    ? `WHERE ${conditions.join(" AND ")}`
    : "";

  const query = `SELECT ${selected.join(
    ", "
  )}, measured_at FROM particle_data ${whereClause} ORDER BY measured_at DESC`;

  try {
    const { rows } = await poolUser.query(query, params);

    res.setHeader("Content-Type", "text/csv");
    res.setHeader(
      "Content-Disposition",
      "attachment; filename=particle_data.csv"
    );

    const csvStream = format({ headers: true });
    csvStream.pipe(res);
    rows.forEach((row) => csvStream.write(row));
    csvStream.end();
  } catch (err) {
    console.error("❌ Query Error:", err);
    res.status(500).json({ msg: "Server Error" });
  }
});

//Wind Data

app.get("/download/wind-data", authenticateJWT, async (req, res) => {
  const { fields, start, end } = req.query;

  const allowedFields = [
    "temperature",
    "humidity",
    "pressure",
    "wind_speed",
    "wind_direction",
  ];
  const selected = fields
    ? fields.split(",").filter((f) => allowedFields.includes(f))
    : allowedFields;

  if (selected.length === 0) {
    return res.status(400).json({ msg: "No valid fields selected" });
  }

  const conditions = [];
  const params = [];

  if (start) {
    const paramIndex = params.length + 1;
    conditions.push(`measured_at >= $${paramIndex}`);
    params.push(start);
  }

  if (end) {
    const paramIndex = params.length + 1;
    conditions.push(`measured_at <= $${paramIndex}`);
    params.push(end);
  }

  const whereClause = conditions.length
    ? `WHERE ${conditions.join(" AND ")}`
    : "";

  const query = `SELECT ${selected.join(
    ", "
  )}, measured_at FROM wind_data ${whereClause} ORDER BY measured_at DESC`;

  try {
    const { rows } = await poolUser.query(query, params);

    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", "attachment; filename=wind_data.csv");

    const csvStream = format({ headers: true });
    csvStream.pipe(res);
    rows.forEach((row) => csvStream.write(row));
    csvStream.end();
  } catch (err) {
    console.error("❌ Wind data query error:", err);
    res.status(500).json({ msg: "Server Error" });
  }
});

// ------------------------------
// PDF Download Endpoints
// ------------------------------

const ejs = require("ejs");
const puppeteer = require("puppeteer");
const path = require("path");
const fs = require("fs");

app.get("/report/pdf", authenticateJWT, async (req, res) => {
  const { dataType, start, end, fields } = req.query;

  const tables = {
    wind: {
      name: "wind_data",
      allowed: [
        "temperature",
        "humidity",
        "pressure",
        "wind_speed",
        "wind_direction",
      ],
    },
    particle: {
      name: "particle_data",
      allowed: ["pm25", "pm10", "tsp"],
    },
  };

  if (!tables[dataType]) return res.status(400).send("Invalid dataType");

  const selected = fields
    ? fields.split(",").filter((f) => tables[dataType].allowed.includes(f))
    : tables[dataType].allowed;

  if (selected.length === 0) {
    return res.status(400).json({ msg: "No valid fields selected" });
  }

  const conditions = [];
  const params = [];

  if (start) {
    const idx = params.length + 1;
    conditions.push(`measured_at >= $${idx}`);
    params.push(start);
  }
  if (end) {
    const idx = params.length + 1;
    conditions.push(`measured_at <= $${idx}`);
    params.push(end);
  }

  const whereClause = conditions.length
    ? `WHERE ${conditions.join(" AND ")}`
    : "";

  const query = `SELECT ${selected.join(", ")}, measured_at FROM ${
    tables[dataType].name
  } ${whereClause} ORDER BY measured_at ASC`;

  try {
    const { rows } = await poolUser.query(query, params);

    const stats = {
      total: rows.length,
      averageTemperature:
        dataType === "wind"
          ? (
              rows.reduce((acc, r) => acc + (r.temperature || 0), 0) /
              rows.filter((r) => r.temperature != null).length
            ).toFixed(1)
          : undefined,
    };

    const templatePath = path.join(
      __dirname,
      "reports",
      "templates",
      "report-template.ejs"
    );
    const html = await ejs.renderFile(templatePath, {
      dataType,
      startDate: start,
      endDate: end,
      generatedAt: new Date().toLocaleString(),
      fields: selected,
      data: rows,
      stats,
      chartUrl: null,
    });

    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: "networkidle0" });
    const pdfBuffer = await page.pdf({ format: "A4", printBackground: true });
    await browser.close();

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename=${dataType}_report.pdf`
    );
    res.send(pdfBuffer);
  } catch (err) {
    console.error("PDF generation error:", err);
    res.status(500).send("Failed to generate report");
  }
});

// ------------------------------
// Alert Rules
// ------------------------------

app.post("/alert-rule", authenticateJWT, async (req, res) => {
  const { parameter, threshold, telegram_username, enabled } = req.body;
  const userId = req.user.id;

  if (!parameter || !threshold || !telegram_username) {
    return res.status(400).json({ msg: "Missing fields" });
  }

  try {
    const lookup = await poolUser.query(
      `SELECT chat_id FROM telegram_users WHERE username = $1`,
      [telegram_username.replace("@", "")]
    );

    if (lookup.rows.length === 0) {
      return res.status(400).json({
        msg: "Telegram username not registered. Please start the bot first.",
      });
    }

    const chatId = lookup.rows[0].chat_id;

    const result = await poolUser.query(
      `INSERT INTO alert_rules (user_id, parameter, threshold, telegram_chat_id, username, enabled)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [userId, parameter, threshold, chatId, telegram_username, enabled]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("Error inserting alert rule:", err);
    res.status(500).json({ msg: "Database error" });
  }
});

app.get("/alert-rules", authenticateJWT, async (req, res) => {
  const userId = req.user.id;

  try {
    const result = await poolUser.query(
      `SELECT * FROM alert_rules WHERE user_id = $1 ORDER BY created_at DESC`,
      [userId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching alert rules:", err);
    res.status(500).json({ msg: "Database error" });
  }
});

// ------------------------------
// Check Alert Rules
// ------------------------------

const axios = require("axios");

async function checkAlertRules() {
  try {
    const { rows: rules } = await poolUser.query(
      `SELECT * FROM alert_rules WHERE enabled = true`
    );

    console.log(`🔍 Found ${rules.length} active alert rules`);

    for (const rule of rules) {
      const { id, parameter, threshold, username } = rule;

      if (!username) {
        console.warn(`⚠️ Rule ${id} has no telegram username`);
        continue;
      }

      console.log(`---\nEvaluating rule for ${parameter} > ${threshold}`);
      console.log(`Looking up chat_id for @${username}`);

      // Lookup chat_id by username
      const tg = await poolUser.query(
        `SELECT chat_id FROM telegram_users WHERE username = $1`,
        [username.replace(/^@/, "")]
      );

      if (!tg.rows.length) {
        console.warn(`⚠️ No chat_id found for Telegram user: @${username}`);
        continue;
      }

      const chat_id = tg.rows[0].chat_id;

      // Fetch latest sensor value
      const sensorQuery = `SELECT ${parameter} FROM particle_data ORDER BY measured_at DESC LIMIT 1`;
      const { rows: sensorData } = await poolUser.query(sensorQuery);

      if (sensorData.length && sensorData[0][parameter] > threshold) {
        const value = sensorData[0][parameter];
        const message = `🚨 Alert: *${parameter.toUpperCase()}* exceeded threshold!\nCurrent value: *${value}* µg/m³\nThreshold: *${threshold}* µg/m³`;

        await axios.post(
          `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`,
          {
            chat_id,
            text: message,
            parse_mode: "Markdown",
          }
        );

        console.log(`✅ Sent alert to ${chat_id} (@${username})`);
      }
    }
  } catch (err) {
    console.error("❌ Alert check error:", err.message);
  }
}
setInterval(checkAlertRules, 60000); // Check every minute

// ------------------------------
// Telegram Webhook
// ------------------------------
app.post("/telegram/webhook", express.json(), async (req, res) => {
  const message = req.body?.message;
  if (!message) return res.sendStatus(200);

  const chatId = message.chat.id;
  const from = message.from;

  // Fallback: use a pseudo-username if real one is missing
  const username = from.username || `${from.first_name || "user"}_${from.id}`;

  try {
    await poolUser.query(
      `INSERT INTO telegram_users (username, chat_id)
       VALUES ($1, $2)
       ON CONFLICT (username) DO UPDATE SET chat_id = $2`,
      [username, chatId]
    );

    await axios.post(
      `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`,
      {
        chat_id: chatId,
        text: `✅ You are now connected to Dasuto Alerts as @${username}`,
      }
    );

    console.log(`✅ Registered Telegram user: @${username}`);
  } catch (err) {
    console.error("❌ Failed to register Telegram user:", err.message);
  }

  res.sendStatus(200);
});

// -----------------------------------------------------------------
// GET /licenses — list all licenses (admin only)
// -----------------------------------------------------------------
app.get("/licenses", authenticateJWT, authorizeAdmin, async (req, res) => {
  try {
    const result = await poolAdmin.query(
      `SELECT licenses.*, users.username 
       FROM licenses
       LEFT JOIN users ON licenses.user_id = users.id
       ORDER BY issued_at DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching licenses:", err);
    res.status(500).json({ message: "Internal server error" });
  }
});

// -----------------------------------------------------------------
// POST /licenses/assign — assign a license to a user (admin only)
// -----------------------------------------------------------------
app.post(
  "/licenses/assign",
  authenticateJWT,
  authorizeAdmin,
  async (req, res) => {
    const { license_id, user_id } = req.body;

    if (!license_id) {
      return res.status(400).json({ msg: "license_id is required" });
    }

    try {
      await poolAdmin.query(`UPDATE licenses SET user_id = $1 WHERE id = $2`, [
        user_id || null,
        license_id,
      ]);

      res.status(200).json({ msg: "License assignment updated" });
    } catch (err) {
      console.error("Error assigning license:", err);
      res.status(500).json({ msg: "Server Error" });
    }
  }
);

// -----------------------------------------------------------------
// POST /licenses — create a new license (admin only)
// -----------------------------------------------------------------

app.post("/licenses", authenticateJWT, authorizeAdmin, async (req, res) => {
  const { license_key, company, issued_at, expires_at, status } = req.body;

  if (!license_key || !issued_at || !expires_at || !status) {
    return res.status(400).json({ msg: "Missing required fields" });
  }

  try {
    const result = await poolAdmin.query(
      `INSERT INTO licenses (license_key, company, issued_at, expires_at, status)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [license_key, company || null, issued_at, expires_at, status]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("Error creating license:", err);
    res.status(500).json({ msg: "Server Error" });
  }
});

// -----------------------------------------------------------------
// DELETE - Delete a license by ID (admin only)
// -----------------------------------------------------------------

app.delete(
  "/licenses/:id",
  authenticateJWT,
  authorizeAdmin,
  async (req, res) => {
    const { id } = req.params;

    try {
      const result = await poolAdmin.query(
        `DELETE FROM licenses WHERE id = $1 RETURNING *`,
        [id]
      );

      if (result.rowCount === 0) {
        return res.status(404).json({ msg: "License not found" });
      }

      res.status(200).json({ msg: "License deleted successfully" });
    } catch (err) {
      console.error("Error deleting license:", err);
      res.status(500).json({ msg: "Server Error" });
    }
  }
);
